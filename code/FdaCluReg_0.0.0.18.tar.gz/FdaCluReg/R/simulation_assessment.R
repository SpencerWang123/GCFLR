simulation_assement=function(x){return(x^2)}
